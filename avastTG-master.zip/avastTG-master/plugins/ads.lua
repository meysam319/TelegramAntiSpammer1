do
 function run(msg, matches)
return [[ 
کانال رسمی تیم بزرگ آواست!جدید ترین نوآوری ها و... 
https://telegram.me/avast_team
https://telegram.me/avast_team
https://telegram.me/avast_team
]]
end
return {
patterns = {
"^(تبلیغ)$",
},
run = run
}
end
