
local function run(msg, matches)
if msg.to.type == 'chat' then
    if is_momod(msg) then
        return
    end
    local data = load_data(_config.moderation.data)
    if data[tostring(msg.to.id)] then
        if data[tostring(msg.to.id)]['settings'] then
            if data[tostring(msg.to.id)]['settings']['lock_link'] then
                lock_adds = data[tostring(msg.to.id)]['settings']['lock_link']
            end
        end
    end
    local chat = get_receiver(msg)
    local user = "user#id"..msg.from.id
    if lock_adds == "yes" then
    end
end
 end
return {
    usage ={
        "lock adds: If User Send A Link Then Removed From Bot.",
        "unlock adds: Adds Is Enabled.",
        },
  patterns = {
    "[Tt][Ee][Ll][Ee][Gg][Rr][Aa][Mm].[Mm][Ee]/[Jj][Oo][Ii][Nn][Cc][Hh][Aa][Tt]/",
        "[Tt][Ee][Ll][Ee][Gg][Rr][Aa][Mm].[Mm][Ee]",
    "[Ht][Tt][Tt][Pp][Ss]://",
    "[Ht][Tt][Tt][Pp]://",
    "[Ww][Ww][Ww].",
  },
  run = run
}
