avast bot is open source!

اعضای تیم آواست:
@arashnomiri
@Oo_sArDaR_marginam_oO
@redteam_01_01
@Pukeram
@iq_plus
@negative_officiall
@DrCyber1736

کانال:
@avast_Team
